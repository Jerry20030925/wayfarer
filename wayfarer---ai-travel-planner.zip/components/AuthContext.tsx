
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, StoredUser } from '../types'; // Assuming StoredUser is defined for mock password handling

// --- Mock Database (localStorage) ---
const USERS_STORAGE_KEY = 'wayfarer_users';
const CURRENT_USER_STORAGE_KEY = 'wayfarer_current_user';

const getStoredUsers = (): StoredUser[] => {
  const usersJson = localStorage.getItem(USERS_STORAGE_KEY);
  return usersJson ? JSON.parse(usersJson) : [];
};

const storeUsers = (users: StoredUser[]) => {
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
};

const getStoredCurrentUser = (): User | null => {
  const userJson = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
  return userJson ? JSON.parse(userJson) : null;
};

const storeCurrentUser = (user: User | null) => {
  if (user) {
    localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(CURRENT_USER_STORAGE_KEY);
  }
};
// --- End Mock Database ---


interface AuthContextType {
  currentUser: User | null;
  isLoading: boolean;
  login: (email: string, passwordAttempt: string) => Promise<User | null>;
  logout: () => Promise<void>;
  register: (name: string, email: string, passwordNew: string) => Promise<User | null>;
  updateUser: (updatedInfo: Partial<Omit<User, 'id' | 'email'>>) => Promise<User | null>; // email typically not changed without verification
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true); // Start with loading true

  useEffect(() => {
    // Simulate async loading of user from storage
    const storedUser = getStoredCurrentUser();
    if (storedUser) {
      setCurrentUser(storedUser);
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, passwordAttempt: string): Promise<User | null> => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    const users = getStoredUsers();
    const userFound = users.find(u => u.email.toLowerCase() === email.toLowerCase());

    // Basic password check (in a real app, this would be secure hashing and comparison)
    if (userFound && userFound.hashedPassword === `mock_${passwordAttempt}`) {
      const loggedInUser: User = { id: userFound.id, name: userFound.name, email: userFound.email };
      setCurrentUser(loggedInUser);
      storeCurrentUser(loggedInUser);
      setIsLoading(false);
      return loggedInUser;
    }
    setIsLoading(false);
    return null;
  };

  const logout = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 300));
    setCurrentUser(null);
    storeCurrentUser(null);
    setIsLoading(false);
  };

  const register = async (name: string, email: string, passwordNew: string): Promise<User | null> => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    const users = getStoredUsers();
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      setIsLoading(false);
      throw new Error("User with this email already exists."); // Simulate conflict
    }
    const newUser: StoredUser = {
      id: Date.now().toString(), // simple unique ID
      name,
      email,
      hashedPassword: `mock_${passwordNew}` // Mock hashing
    };
    users.push(newUser);
    storeUsers(users);
    
    // Automatically log in the new user
    const registeredUser: User = { id: newUser.id, name: newUser.name, email: newUser.email };
    setCurrentUser(registeredUser);
    storeCurrentUser(registeredUser);
    setIsLoading(false);
    return registeredUser;
  };

  const updateUser = async (updatedInfo: Partial<Omit<User, 'id' | 'email'>>): Promise<User | null> => {
    if (!currentUser) {
      throw new Error("No user logged in to update.");
    }
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const users = getStoredUsers();
    const userIndex = users.findIndex(u => u.id === currentUser.id);

    if (userIndex === -1) {
      setIsLoading(false);
      throw new Error("User not found in storage.");
    }

    const updatedUser = { ...users[userIndex], ...updatedInfo } as StoredUser;
    users[userIndex] = updatedUser;
    storeUsers(users);

    const updatedCurrentUser: User = { id: updatedUser.id, name: updatedUser.name, email: updatedUser.email };
    setCurrentUser(updatedCurrentUser);
    storeCurrentUser(updatedCurrentUser);
    setIsLoading(false);
    return updatedCurrentUser;
  };


  return (
    <AuthContext.Provider value={{ currentUser, isLoading, login, logout, register, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
