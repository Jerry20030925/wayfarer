
import React from 'react';
import { TripSuggestion } from '../types';
import { CalendarDaysIcon, CurrencyDollarIcon, LightBulbIcon, LocationPinIcon, TagIcon } from './IconComponents';

interface SuggestionCardProps {
  suggestion: TripSuggestion;
}

const SuggestionCard: React.FC<SuggestionCardProps> = ({ suggestion }) => {
  const { 
    destinationName, 
    description, 
    suggestedActivities, 
    estimatedCostUSD, 
    bestTimeToVisit, 
    imageUrl,
    isTopSuggestion
  } = suggestion;

  return (
    <div className={`bg-white shadow-lg rounded-xl overflow-hidden transform transition-all hover:scale-105 duration-300 ${isTopSuggestion ? 'border-4 border-teal-500' : ''}`}>
      {isTopSuggestion && (
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-teal-500 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-md z-10">
          ✨ Top Suggestion
        </div>
      )}
      <img 
        src={imageUrl || `https://picsum.photos/seed/${encodeURIComponent(destinationName)}/600/400`} 
        alt={destinationName} 
        className="w-full h-56 object-cover" 
      />
      <div className="p-6">
        <h3 className="text-2xl font-semibold text-slate-800 mb-2 flex items-center">
          <LocationPinIcon className="w-6 h-6 mr-2 text-teal-600" /> {destinationName}
        </h3>
        <p className="text-slate-600 text-sm mb-4">{description}</p>
        
        <div className="space-y-3 mb-4">
          {suggestedActivities && suggestedActivities.length > 0 && (
            <div className="flex items-start">
              <LightBulbIcon className="w-5 h-5 text-amber-500 mr-2 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-medium text-slate-700">Suggested Activities:</h4>
                <ul className="list-disc list-inside text-sm text-slate-500 pl-1">
                  {suggestedActivities.slice(0, 3).map((activity, index) => (
                    <li key={index}>{activity}</li>
                  ))}
                  {suggestedActivities.length > 3 && <li>...and more!</li>}
                </ul>
              </div>
            </div>
          )}
          
          {estimatedCostUSD && (
            <div className="flex items-center">
              <CurrencyDollarIcon className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
              <p className="text-sm text-slate-600"><span className="font-medium text-slate-700">Budget:</span> ~${estimatedCostUSD} (USD)</p>
            </div>
          )}

          {bestTimeToVisit && (
            <div className="flex items-center">
              <CalendarDaysIcon className="w-5 h-5 text-blue-500 mr-2 flex-shrink-0" />
              <p className="text-sm text-slate-600"><span className="font-medium text-slate-700">Best Time to Visit:</span> {bestTimeToVisit}</p>
            </div>
          )}
        </div>

        {/* Placeholder for future actions */}
        {/* <button className="mt-4 w-full bg-teal-500 hover:bg-teal-600 text-white font-medium py-2 px-4 rounded-lg text-sm transition-colors">
          Explore this Idea
        </button> */}
      </div>
    </div>
  );
};

export default SuggestionCard;
