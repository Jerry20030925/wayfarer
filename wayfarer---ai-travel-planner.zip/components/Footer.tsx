
import React from 'react';
import { Link } from 'react-router-dom';
import { APP_NAME, FOOTER_LINKS } from '../constants';


interface FooterProps {
  isLandingPage?: boolean;
}

const Footer: React.FC<FooterProps> = ({ isLandingPage = false }) => {
  const bgColor = isLandingPage ? 'bg-transparent' : 'bg-slate-100';
  const textColor = isLandingPage ? 'text-slate-500' : 'text-slate-600';
  const linkColor = isLandingPage ? 'hover:text-slate-700' : 'hover:text-teal-600';

  return (
    <footer className={`${bgColor} border-t border-slate-200`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
        <div className="flex justify-center space-x-6 mb-4">
          {FOOTER_LINKS.map(link => (
             <Link key={link.name} to={link.path} className={`text-sm ${textColor} ${linkColor} transition-colors`}>
               {link.name}
             </Link>
          ))}
        </div>
        <p className={`text-sm ${textColor}`}>
          &copy; {new Date().getFullYear()} {APP_NAME}. Inspiring your next journey.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
