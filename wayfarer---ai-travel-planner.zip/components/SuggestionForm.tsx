
import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SuggestionFormData } from '../types';
import { INITIAL_BUDGET, DEFAULT_BUDGET_MIN, DEFAULT_BUDGET_MAX, DEFAULT_BUDGET_STEP, INTEREST_OPTIONS, TRAVEL_STYLE_OPTIONS } from '../constants';
import { ArrowRightIcon, CalendarDaysIcon, CurrencyDollarIcon, LightBulbIcon, TagIcon } from './IconComponents';

interface SuggestionFormProps {
  onSubmit: (data: SuggestionFormData) => void;
  isLoading: boolean;
}

const SuggestionForm: React.FC<SuggestionFormProps> = ({ onSubmit, isLoading }) => {
  const [searchParams] = useSearchParams();
  const initialKeywords = searchParams.get('keywords') || '';

  const [formData, setFormData] = useState<SuggestionFormData>({
    destinationKeywords: initialKeywords,
    tripDuration: '7 days',
    estimatedBudget: INITIAL_BUDGET,
    interests: '',
    travelStyle: '',
  });

  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [selectedTravelStyles, setSelectedTravelStyles] = useState<string[]>([]);

  useEffect(() => {
    setFormData(prev => ({ ...prev, destinationKeywords: initialKeywords }));
  }, [initialKeywords]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'estimatedBudget' ? parseInt(value, 10) : value }));
  };

  const handleInterestToggle = (interest: string) => {
    setSelectedInterests(prev =>
      prev.includes(interest) ? prev.filter(i => i !== interest) : [...prev, interest]
    );
  };
  
  const handleTravelStyleToggle = (style: string) => {
    setSelectedTravelStyles(prev =>
      prev.includes(style) ? prev.filter(s => s !== style) : [...prev, style]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      interests: selectedInterests.join(', '),
      travelStyle: selectedTravelStyles.join(', '),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 p-6 md:p-8 bg-white shadow-xl rounded-xl">
      <div>
        <h2 className="text-2xl font-semibold text-slate-700 mb-1">Where are you dreaming of?</h2>
        <p className="text-sm text-slate-500 mb-4">Tell us your initial thoughts, and we'll help you refine them.</p>
      </div>

      {/* Destination Keywords */}
      <div>
        <label htmlFor="destinationKeywords" className="block text-sm font-medium text-slate-700 mb-1">
          Destination Keywords
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <LightBulbIcon className="h-5 w-5 text-slate-400" />
          </div>
          <input
            type="text"
            name="destinationKeywords"
            id="destinationKeywords"
            value={formData.destinationKeywords}
            onChange={handleChange}
            placeholder="e.g., Beaches, Mountains, City Break"
            className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
          />
        </div>
      </div>

      {/* Trip Duration */}
      <div>
        <label htmlFor="tripDuration" className="block text-sm font-medium text-slate-700 mb-1">
          Trip Duration (approx.)
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <CalendarDaysIcon className="h-5 w-5 text-slate-400" />
          </div>
          <input
            type="text"
            name="tripDuration"
            id="tripDuration"
            value={formData.tripDuration}
            onChange={handleChange}
            placeholder="e.g., 7 days, Weekend"
            className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 sm:text-sm"
          />
        </div>
      </div>
      
      {/* Estimated Budget */}
      <div>
        <label htmlFor="estimatedBudget" className="block text-sm font-medium text-slate-700 mb-1">
          Estimated Budget (USD) per person: ${formData.estimatedBudget.toLocaleString()}
        </label>
        <div className="relative flex items-center">
            <CurrencyDollarIcon className="h-5 w-5 text-slate-400 mr-2" />
            <input
              type="range"
              name="estimatedBudget"
              id="estimatedBudget"
              min={DEFAULT_BUDGET_MIN}
              max={DEFAULT_BUDGET_MAX}
              step={DEFAULT_BUDGET_STEP}
              value={formData.estimatedBudget}
              onChange={handleChange}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-600"
            />
        </div>
        <p className="text-xs text-slate-500 mt-1">This helps us suggest activities and destinations within your preferred cost range. No bookings are made.</p>
      </div>

      {/* Interests */}
      <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Your Interests <span className="text-xs text-slate-500">(select multiple)</span>
          </label>
          <div className="flex flex-wrap gap-2">
            {INTEREST_OPTIONS.map(interest => (
              <button
                type="button"
                key={interest}
                onClick={() => handleInterestToggle(interest)}
                className={`px-3 py-1.5 border rounded-full text-sm font-medium transition-colors
                  ${selectedInterests.includes(interest) 
                    ? 'bg-teal-500 text-white border-teal-500' 
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'}`}
              >
                {interest}
              </button>
            ))}
          </div>
      </div>
       
      {/* Travel Style */}
      <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Preferred Travel Style <span className="text-xs text-slate-500">(select multiple)</span>
          </label>
          <div className="flex flex-wrap gap-2">
            {TRAVEL_STYLE_OPTIONS.map(style => (
              <button
                type="button"
                key={style}
                onClick={() => handleTravelStyleToggle(style)}
                className={`px-3 py-1.5 border rounded-full text-sm font-medium transition-colors
                  ${selectedTravelStyles.includes(style) 
                    ? 'bg-sky-500 text-white border-sky-500' 
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'}`}
              >
                {style}
              </button>
            ))}
          </div>
      </div>


      <button
        type="submit"
        disabled={isLoading}
        className="w-full flex items-center justify-center bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 px-4 rounded-lg shadow-md transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Generating Ideas...
          </>
        ) : (
          <>
            Get AI Suggestions <ArrowRightIcon className="ml-2" />
          </>
        )}
      </button>
    </form>
  );
};

export default SuggestionForm;
