
import React, { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { WayfarerLogo, UserCircleIcon, LogoutIcon } from './IconComponents';
import { useAuth } from './AuthContext';

const baseNavLinks = [
  { name: "Get Suggestions", path: "/get-suggestions" },
  { name: "Explore Ideas", path: "/explore" },
  // My Trips will be added conditionally
  { name: "About", path: "/about" },
];

const Header: React.FC = () => {
  const { currentUser, logout, isLoading } = useAuth();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/'); // Redirect to home page after logout
  };

  const navLinks = currentUser 
    ? [...baseNavLinks.slice(0, 2), { name: "My Trips", path: "/my-trips" }, ...baseNavLinks.slice(2)]
    : baseNavLinks;

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <NavLink to="/" className="flex items-center" aria-label="Wayfarer Home">
             <WayfarerLogo iconColor="text-teal-600" textColor="text-slate-800" />
          </NavLink>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {navLinks.map((link) => (
              <NavLink
                key={link.name}
                to={link.path}
                className={({ isActive }) =>
                  `text-sm font-medium transition-colors hover:text-teal-600 ${
                    isActive ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-600'
                  }`
                }
              >
                {link.name}
              </NavLink>
            ))}
          </nav>

          {/* Auth Links / User Menu - Desktop */}
          <div className="hidden md:flex items-center space-x-4">
            {isLoading ? (
              <div className="text-sm text-slate-500">Loading...</div>
            ) : currentUser ? (
              <>
                <NavLink 
                  to="/profile" 
                  className="flex items-center text-sm font-medium text-slate-600 hover:text-teal-600 transition-colors"
                  title={currentUser.name}
                >
                  <UserCircleIcon className="w-6 h-6 mr-1.5" />
                  Profile
                </NavLink>
                <button
                  onClick={handleLogout}
                  className="flex items-center text-sm font-medium text-slate-600 hover:text-red-600 transition-colors"
                  title="Logout"
                >
                  <LogoutIcon className="w-5 h-5 mr-1.5" />
                  Logout
                </button>
              </>
            ) : (
              <>
                <NavLink
                  to="/login"
                  className="text-sm font-medium text-slate-600 hover:text-teal-600 transition-colors"
                >
                  Login
                </NavLink>
                <NavLink
                  to="/register"
                  className="bg-teal-500 hover:bg-teal-600 text-white font-medium py-2 px-3 rounded-lg text-sm transition-colors"
                >
                  Sign Up
                </NavLink>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-slate-600 hover:text-teal-600 focus:outline-none"
              aria-label="Toggle menu"
              aria-expanded={isMobileMenuOpen}
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isMobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute w-full z-40">
          <nav className="px-2 pt-2 pb-4 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <NavLink
                key={`mobile-${link.name}`}
                to={link.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) =>
                  `block px-3 py-2 rounded-md text-base font-medium transition-colors ${
                    isActive ? 'bg-teal-50 text-teal-700' : 'text-slate-700 hover:bg-slate-100 hover:text-teal-600'
                  }`
                }
              >
                {link.name}
              </NavLink>
            ))}
             <hr className="my-2 border-slate-200" />
            {isLoading ? (
               <div className="px-3 py-2 text-slate-500">Loading...</div>
            ) : currentUser ? (
              <>
                <NavLink 
                  to="/profile" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:bg-slate-100 hover:text-teal-600"
                >
                  <UserCircleIcon className="w-5 h-5 mr-2" /> {currentUser.name} (Profile)
                </NavLink>
                <button
                  onClick={() => { handleLogout(); setIsMobileMenuOpen(false); }}
                  className="w-full text-left flex items-center px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:bg-slate-100 hover:text-red-600"
                >
                  <LogoutIcon className="w-5 h-5 mr-2" /> Logout
                </button>
              </>
            ) : (
              <>
                <NavLink
                  to="/login"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:bg-slate-100 hover:text-teal-600"
                >
                  Login
                </NavLink>
                <NavLink
                  to="/register"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block mt-1 w-full text-center bg-teal-500 hover:bg-teal-600 text-white font-medium py-2 px-4 rounded-lg text-base transition-colors"
                >
                  Sign Up
                </NavLink>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
