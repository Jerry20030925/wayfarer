
import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import SuggestionForm from '../components/SuggestionForm';
import SuggestionCard from '../components/SuggestionCard';
import { LoadingSpinner, ExternalLinkIcon } from '../components/IconComponents';
import { getTravelSuggestions } from '../services/geminiService';
import { TripSuggestion, SuggestionFormData, GroundingChunk } from '../types';
import { APP_NAME } from '../constants';


const GetSuggestionsPage: React.FC = () => {
  const [suggestions, setSuggestions] = useState<TripSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [groundingChunks, setGroundingChunks] = useState<GroundingChunk[] | undefined>(undefined);
  
  const location = useLocation();

  // Function to trigger generation, can be called on initial load if query params exist
  const handleGenerateSuggestions = useCallback(async (formData: SuggestionFormData) => {
    setIsLoading(true);
    setError(null);
    setSuggestions([]);
    setGroundingChunks(undefined);
    try {
      const result = await getTravelSuggestions(formData);
      setSuggestions(result.suggestions);
      if (result.groundingChunks && result.groundingChunks.length > 0) {
        setGroundingChunks(result.groundingChunks);
      }
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred.");
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Effect to potentially auto-submit if specific query params are present (e.g. from landing page)
  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const keywords = queryParams.get('keywords');
    if (keywords && suggestions.length === 0 && !isLoading) { // Only run if keywords present, no suggestions yet, and not already loading
      // Minimal form data for auto-submission. User can refine later.
      const initialFormData: SuggestionFormData = {
        destinationKeywords: keywords,
        tripDuration: '7 days', // Default
        estimatedBudget: 2000, // Default
        interests: '', // User can fill this
        travelStyle: '', // User can fill this
      };
      handleGenerateSuggestions(initialFormData);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search, handleGenerateSuggestions]); // Removed suggestions.length and isLoading to avoid loop if API key is missing and mock data is returned


  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold tracking-tight text-slate-800 sm:text-5xl">
            Discover Your Next Adventure
          </h1>
          <p className="mt-4 text-lg leading-7 text-slate-600">
            {APP_NAME} offers AI-powered travel suggestions to inspire your journey. We provide ideas, not bookings.
          </p>
        </div>

        <div className="mb-12">
          <SuggestionForm onSubmit={handleGenerateSuggestions} isLoading={isLoading} />
        </div>

        {isLoading && (
          <div className="flex flex-col items-center justify-center text-center py-12">
            <LoadingSpinner size="w-16 h-16" color="border-teal-500" />
            <p className="mt-4 text-xl font-medium text-slate-600">Generating brilliant ideas for you...</p>
            <p className="text-sm text-slate-500">This might take a moment.</p>
          </div>
        )}

        {error && (
          <div className="text-center py-12">
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative" role="alert">
              <strong className="font-bold">Oops! </strong>
              <span className="block sm:inline">{error}</span>
            </div>
          </div>
        )}

        {!isLoading && !error && suggestions.length > 0 && (
          <div>
            <h2 className="text-3xl font-semibold text-slate-800 mb-8 text-center">
              Your AI-Generated Travel Ideas
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {suggestions.map((suggestion) => (
                <SuggestionCard key={suggestion.id} suggestion={suggestion} />
              ))}
            </div>
            {groundingChunks && groundingChunks.length > 0 && (
              <div className="mt-12 p-6 bg-slate-50 rounded-lg shadow">
                <h3 className="text-xl font-semibold text-slate-700 mb-3">Information Sources:</h3>
                <ul className="list-disc list-inside space-y-1">
                  {groundingChunks.map((chunk, index) => {
                    const source = chunk.web || chunk.retrievedContext;
                    if (source?.uri) {
                      return (
                        <li key={index} className="text-sm text-slate-600">
                          <a 
                            href={source.uri} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-teal-600 hover:text-teal-700 hover:underline inline-flex items-center"
                          >
                            {source.title || source.uri}
                            <ExternalLinkIcon className="w-3 h-3 ml-1" />
                          </a>
                        </li>
                      );
                    }
                    return null;
                  })}
                </ul>
              </div>
            )}
          </div>
        )}
        
        {!isLoading && !error && suggestions.length === 0 && !location.search.includes('keywords=') && ( // Show only if not initial load with keywords
           <div className="text-center py-12">
            <img src="https://picsum.photos/seed/travel-inspiration/400/300" alt="Travel Inspiration" className="mx-auto rounded-lg shadow-md mb-6" />
            <p className="text-xl text-slate-600">Fill out the form above to start your journey planning!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default GetSuggestionsPage;
