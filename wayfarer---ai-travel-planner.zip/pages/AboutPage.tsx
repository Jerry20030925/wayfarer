
import React from 'react';
import { APP_NAME } from '../constants';
import { WayfarerLogo, SparklesIcon } from '../components/IconComponents';

const AboutPage: React.FC = () => {
  return (
    <div className="bg-white py-12 sm:py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
            <WayfarerLogo className="h-12 mx-auto mb-6" iconColor="text-teal-600" textColor="text-slate-800" />
          <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
            About {APP_NAME}
          </h1>
          <p className="mt-6 text-lg leading-8 text-slate-600">
            {APP_NAME} is your personal AI-powered travel companion, designed to inspire your next journey by providing tailored travel suggestions. We believe that planning your adventure should be as exciting as the trip itself.
          </p>
        </div>

        <div className="mt-16 max-w-4xl mx-auto space-y-12">
          <div className="p-8 bg-slate-50 rounded-xl shadow-lg">
            <div className="flex items-center mb-4">
                <SparklesIcon className="h-8 w-8 text-teal-500 mr-3" />
                <h2 className="text-2xl font-semibold text-slate-800">Our Mission</h2>
            </div>
            <p className="text-slate-600 leading-relaxed">
              Our mission is to make travel planning effortless and inspiring. By leveraging the power of artificial intelligence, we aim to understand your unique preferences – from destination keywords and trip duration to budget, interests, and travel style. {APP_NAME} then crafts personalized travel ideas, helping you discover destinations and experiences you might not have found otherwise.
            </p>
          </div>

          <div className="p-8 bg-slate-50 rounded-xl shadow-lg">
            <div className="flex items-center mb-4">
                <SparklesIcon className="h-8 w-8 text-teal-500 mr-3" />
                <h2 className="text-2xl font-semibold text-slate-800">How It Works</h2>
            </div>
            <p className="text-slate-600 leading-relaxed">
              Simply tell us what you're dreaming of! Provide some initial thoughts in our suggestion form. Our advanced AI, powered by Google's Gemini models, analyzes your input to generate a curated list of travel suggestions. Each suggestion includes a destination overview, key activities, estimated costs, and the best time to visit. We provide the inspiration; you create the memories.
            </p>
            <p className="mt-4 text-slate-600 leading-relaxed">
              Please note: {APP_NAME} provides travel ideas and inspiration, not bookings. We help you discover where to go; the adventure of getting there is yours to plan!
            </p>
          </div>

          <div className="p-8 bg-slate-50 rounded-xl shadow-lg">
            <div className="flex items-center mb-4">
                <SparklesIcon className="h-8 w-8 text-teal-500 mr-3" />
                <h2 className="text-2xl font-semibold text-slate-800">Our Technology</h2>
            </div>
            <p className="text-slate-600 leading-relaxed">
              {APP_NAME} utilizes state-of-the-art AI technology, specifically Google's Gemini API, to process your requests and generate creative and relevant travel suggestions. We are committed to providing high-quality, diverse, and inspiring ideas to fuel your wanderlust.
            </p>
          </div>
        </div>
        
        <div className="mt-16 text-center">
            <p className="text-slate-600">Ready to find your next destination?</p>
            <a 
                href="#/get-suggestions" 
                className="mt-4 inline-block bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors"
            >
                Get Travel Suggestions
            </a>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
