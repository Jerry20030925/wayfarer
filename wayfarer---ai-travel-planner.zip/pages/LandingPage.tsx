
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { SearchIcon, WayfarerLogo } from '../components/IconComponents';

const LandingPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/get-suggestions?keywords=${encodeURIComponent(searchTerm.trim())}`);
    } else {
      navigate('/get-suggestions');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen hero-bg text-slate-700 p-4">
      <div className="text-center max-w-2xl">
        <div className="mb-8 flex justify-center">
           <WayfarerLogo className="h-12" iconColor="text-teal-600" textColor="text-slate-700" />
        </div>
        
        <h1 className="text-5xl md:text-6xl font-bold mb-6">
          Where should I go?
        </h1>
        <p className="text-lg md:text-xl text-slate-600 mb-10">
          Get AI-powered travel suggestions tailored to your interests.
        </p>

        <form onSubmit={handleSearch} className="max-w-xl mx-auto">
          <div className="relative flex items-center shadow-lg rounded-full overflow-hidden">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="e.g., 'relaxing beach vacation', 'city exploration'"
              className="w-full py-4 px-6 text-slate-700 placeholder-slate-400 focus:outline-none text-lg"
            />
            <button
              type="submit"
              className="absolute right-0 top-0 bottom-0 bg-teal-500 hover:bg-teal-600 text-white p-4 rounded-full m-1 transition-colors"
              aria-label="Search"
            >
              <SearchIcon className="w-6 h-6" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LandingPage;
