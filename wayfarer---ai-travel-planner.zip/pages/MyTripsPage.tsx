
import React, { useState } from 'react';
import { CalendarDaysIcon, LocationPinIcon } from '../components/IconComponents'; // Assuming you have these

const sampleTrips = [
  {
    id: '1',
    title: 'Parisian Adventure',
    dateRange: '15 Aug 2024 - 22 Aug 2024',
    description: 'Trip to Paris, France. Exploring iconic landmarks and planning activities.',
    imageUrl: 'https://picsum.photos/seed/paris/400/200',
    progress: 75,
    status: 'upcoming',
  },
  {
    id: '2',
    title: 'Kyoto Cultural Immersion',
    dateRange: '05 Sep 2024 - 12 Sep 2024',
    description: 'Exploring ancient temples and gardens in Kyoto, Japan. Planning itinerary and activities.',
    imageUrl: 'https://picsum.photos/seed/kyoto/400/200',
    progress: 40,
    status: 'upcoming',
  },
  {
    id: '3',
    title: 'Rome Historical Tour',
    dateRange: '10 Mar 2024 - 17 Mar 2024',
    description: 'Visited ancient Roman sites and enjoyed Italian cuisine.',
    imageUrl: 'https://picsum.photos/seed/rome/400/200',
    progress: 100,
    status: 'past',
  }
];

const MyTripsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');

  const filteredTrips = sampleTrips.filter(trip => trip.status === activeTab);

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-4 md:mb-0">My Trips</h1>
        <button className="bg-teal-500 hover:bg-teal-600 text-white font-medium py-2 px-4 rounded-lg text-sm transition-colors">
          + Plan a new trip
        </button>
      </div>

      <div className="mb-6 border-b border-slate-200">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'upcoming' 
                ? 'border-teal-500 text-teal-600' 
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'}`}
          >
            Upcoming Trips
          </button>
          <button
            onClick={() => setActiveTab('past')}
            className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'past' 
                ? 'border-teal-500 text-teal-600' 
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'}`}
          >
            Past Trips
          </button>
        </nav>
      </div>

      {filteredTrips.length > 0 ? (
        <div className="space-y-6">
          {filteredTrips.map(trip => (
            <div key={trip.id} className="bg-white shadow-lg rounded-xl overflow-hidden md:flex">
              <img src={trip.imageUrl} alt={trip.title} className="md:w-1/3 h-56 md:h-auto object-cover" />
              <div className="p-6 flex flex-col justify-between flex-grow">
                <div>
                  <h2 className="text-2xl font-semibold text-slate-800 mb-1">{trip.title}</h2>
                  <div className="flex items-center text-sm text-slate-500 mb-2">
                    <CalendarDaysIcon className="w-4 h-4 mr-1.5" />
                    {trip.dateRange}
                  </div>
                  <p className="text-sm text-slate-600 mb-4">{trip.description}</p>
                </div>
                <div>
                  {activeTab === 'upcoming' && (
                    <div className="mb-3">
                      <div className="flex justify-between text-sm text-slate-500 mb-1">
                        <span>Progress</span>
                        <span>{trip.progress}% Planned</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2.5">
                        <div 
                          className="bg-teal-500 h-2.5 rounded-full" 
                          style={{ width: `${trip.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                  <div className="flex flex-wrap gap-2 text-sm">
                    <button className="text-teal-600 hover:text-teal-700 font-medium">View Details</button>
                    {activeTab === 'upcoming' && (
                      <>
                        <span className="text-slate-300">|</span>
                        <button className="text-amber-600 hover:text-amber-700 font-medium">Modify Plan</button>
                        <span className="text-slate-300">|</span>
                        <button className="text-red-600 hover:text-red-700 font-medium">Remove Plan</button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-center text-slate-500 text-lg py-10">
          No {activeTab} trips found. Time to plan your next adventure!
        </p>
      )}

      <div className="mt-12 grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <h3 className="text-lg font-semibold text-slate-700 mb-2">Help Center & FAQs</h3>
            <p className="text-sm text-slate-600 mb-3">Find answers to common questions about trip planning and using Wayfarer.</p>
            <a href="#" className="text-sm text-teal-600 hover:text-teal-700 font-medium">Go to Help Center &rarr;</a>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <h3 className="text-lg font-semibold text-slate-700 mb-2">Contact Wayfarer Support</h3>
            <p className="text-sm text-slate-600 mb-3">Reach out to our support team for assistance with your travel plans.</p>
            <a href="#" className="text-sm text-teal-600 hover:text-teal-700 font-medium">Contact Support &rarr;</a>
        </div>
      </div>

    </div>
  );
};

export default MyTripsPage;
