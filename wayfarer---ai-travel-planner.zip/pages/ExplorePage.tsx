
import React, { useState } from 'react';
import { SearchIcon, LocationPinIcon, TagIcon } from '../components/IconComponents';

const interests = ["All", "Adventure", "Relaxation", "Culture", "Wildlife", "Historical"];

const sampleDestinations = [
  { id: 1, name: "Majestic Mountain Peaks", description: "Discover the serenity of towering mountains, offering breathtaking vistas and invigorating trails for adventurers.", image: "https://picsum.photos/seed/mountains/400/300", tags: ["Adventure", "Nature"] },
  { id: 2, name: "Pristine Coastal Charm", description: "Immerse yourself in sun-drenched beaches with turquoise waters, perfect for relaxation and water sports.", image: "https://picsum.photos/seed/beach/400/300", tags: ["Relaxation", "Beach"] },
  { id: 3, name: "Vibrant Urban Exploration", description: "Experience the bustling energy of iconic cities, rich in culture, history, and culinary delights.", image: "https://picsum.photos/seed/city/400/300", tags: ["Culture", "Urban"] },
  { id: 4, name: "Timeless Historical Sites", description: "Journey through ancient ruins and historic landmarks, uncovering stories from civilizations past.", image: "https://picsum.photos/seed/historical/400/300", tags: ["Historical", "Culture"] },
  { id: 5, name: "Exotic Tropical Paradise", description: "Escape to lush tropical islands with vibrant flora, fauna, and idyllic palm-fringed shores.", image: "https://picsum.photos/seed/tropical/400/300", tags: ["Nature", "Beach", "Relaxation"] },
  { id: 6, name: "Thrilling Wildlife Safari", description: "Embark on an unforgettable safari adventure, encountering majestic wildlife in their natural habitat.", image: "https://picsum.photos/seed/safari/400/300", tags: ["Wildlife", "Adventure"] },
];

const ExplorePage: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredDestinations = sampleDestinations.filter(dest => {
    const matchesFilter = activeFilter === "All" || dest.tags.includes(activeFilter);
    const matchesSearch = dest.name.toLowerCase().includes(searchTerm.toLowerCase()) || dest.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold tracking-tight text-slate-800 sm:text-5xl">Explore Destinations</h1>
        <p className="mt-4 text-lg leading-7 text-slate-600">
          Discover a world of possibilities. Let Wayfarer inspire you with stunning destinations and unique experiences.
        </p>
      </div>

      <div className="mb-8 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex flex-wrap justify-center md:justify-start gap-2">
          {interests.map(interest => (
            <button
              key={interest}
              onClick={() => setActiveFilter(interest)}
              className={`px-4 py-2 text-sm font-medium rounded-full transition-colors
                ${activeFilter === interest 
                  ? 'bg-teal-600 text-white' 
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-100'}`}
            >
              {interest}
            </button>
          ))}
        </div>
        <div className="relative w-full md:w-auto">
          <input 
            type="text"
            placeholder="Search destinations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 border border-slate-300 rounded-full shadow-sm focus:ring-teal-500 focus:border-teal-500 w-full md:w-72"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <SearchIcon className="h-5 w-5 text-slate-400" />
          </div>
        </div>
      </div>

      {filteredDestinations.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredDestinations.map(dest => (
            <div key={dest.id} className="bg-white rounded-lg shadow-lg overflow-hidden transform transition-all hover:scale-105 duration-300">
              <img src={dest.image} alt={dest.name} className="w-full h-48 object-cover"/>
              <div className="p-5">
                <h3 className="text-xl font-semibold text-slate-800 mb-2 flex items-center">
                  <LocationPinIcon className="w-5 h-5 mr-2 text-teal-600 flex-shrink-0" />
                  {dest.name}
                </h3>
                <p className="text-sm text-slate-600 mb-3 leading-relaxed">{dest.description}</p>
                <div className="flex flex-wrap gap-2">
                  {dest.tags.map(tag => (
                    <span key={tag} className="px-2 py-1 bg-teal-100 text-teal-700 text-xs font-medium rounded-full flex items-center">
                      <TagIcon className="w-3 h-3 mr-1" /> {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-center text-slate-500 text-lg py-10">No destinations found matching your criteria. Try adjusting your filters or search term.</p>
      )}
    </div>
  );
};

export default ExplorePage;
