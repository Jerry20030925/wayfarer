
import { GoogleGenAI, GenerateContentResponse, Part } from "@google/genai";
import { SuggestionFormData, TripSuggestion, GroundingChunk } from '../types';
import { GEMINI_TEXT_MODEL } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not found. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

function parseJsonFromMarkdown(text: string): any {
  const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
  const match = text.match(fenceRegex);
  // jsonStr is the string we will attempt to parse, either from within fences or the trimmed original text.
  const jsonStr = match && match[1] ? match[1].trim() : text.trim();
  
  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    // Log details about the parsing attempt that failed.
    console.error(
      "Failed to parse JSON string. Error:", e, 
      "\nAttempted to parse this string:", jsonStr, 
      "\nOriginal raw text from AI:", text
    );
    
    // Fallback: Try to find a JSON array or object within jsonStr, 
    // in case jsonStr itself contained extra non-JSON text that wasn't stripped.
    // This is less likely to help if jsonStr is *supposed* to be pure JSON but is internally malformed.
    const jsonLooseRegex = /\[.*?\]|\{.*?\}/s;
    const looseMatch = jsonStr.match(jsonLooseRegex);
    
    if (looseMatch && looseMatch[0]) {
      const extractedJsonStr = looseMatch[0];
      try {
        return JSON.parse(extractedJsonStr);
      } catch (e2) {
        console.error(
          "Failed to parse JSON even with loose regex extraction. Error:", e2,
          "\nExtracted string attempted for parsing:", extractedJsonStr
        );
      }
    }
    // If all parsing attempts fail, throw an error indicating malformed content from the AI.
    throw new Error(`AI returned a malformed response. Details: ${ (e as Error).message }`);
  }
}


export const getTravelSuggestions = async (
  formData: SuggestionFormData
): Promise<{suggestions: TripSuggestion[], groundingChunks?: GroundingChunk[]}> => {
  if (!API_KEY) {
    console.error("Gemini API key is not configured. Returning mock data.");
    await new Promise(resolve => setTimeout(resolve, 1000));
    return { suggestions: [
      {
        id: "mock1",
        destinationName: "Mock Paris, France",
        description: "A beautiful city for romantic getaways and cultural exploration. Enjoy iconic landmarks and delicious cuisine.",
        suggestedActivities: ["Visit Eiffel Tower", "Louvre Museum Tour", "Seine River Cruise"],
        estimatedCostUSD: "2000-3000",
        bestTimeToVisit: "Spring (Apr-Jun)",
        imagePrompt: "Eiffel Tower during sunset with a couple",
        isTopSuggestion: true,
      },
      {
        id: "mock2",
        destinationName: "Mock Kyoto, Japan",
        description: "Immerse yourself in traditional Japanese culture, serene temples, and beautiful gardens.",
        suggestedActivities: ["Visit Kinkaku-ji (Golden Pavilion)", "Explore Arashiyama Bamboo Grove", "Gion Corner Cultural Show"],
        estimatedCostUSD: "1800-2800",
        bestTimeToVisit: "Autumn (Oct-Nov) for fall foliage",
        imagePrompt: "Golden Pavilion temple in Kyoto with autumn leaves",
      }
    ]};
  }

  const prompt = `
    You are an expert travel consultant for an app called Wayfarer.
    A user is looking for travel suggestions based on the following preferences:
    - Destination Keywords: ${formData.destinationKeywords || 'Anywhere exciting'}
    - Trip Duration: ${formData.tripDuration || 'Flexible'}
    - Estimated Budget (USD per person): $${formData.estimatedBudget || 'Flexible'}
    - Interests: ${formData.interests || 'General sightseeing'}
    - Travel Style: ${formData.travelStyle || 'Comfortable'}

    Please provide 3 diverse travel suggestions. For each suggestion, include:
    1.  destinationName: A concise name for the destination (e.g., "Kyoto, Japan", "Amalfi Coast, Italy").
    2.  description: A captivating summary of the destination (2-3 sentences).
    3.  suggestedActivities: An array of 3-5 key activities or attractions.
    4.  estimatedCostUSD: A string representing the estimated cost range per person for the trip duration (e.g., "1500-2500").
    5.  bestTimeToVisit: A brief note on the best time to visit (e.g., "Spring (April-May)").
    6.  imagePrompt: A descriptive prompt for an AI image generator to create a visually appealing image for this destination (e.g., "Serene view of Mount Fuji with cherry blossoms").

    Format your response as a JSON array of these suggestion objects.
    Example of a single suggestion object:
    {
      "destinationName": "Paris, France",
      "description": "The city of lights, offering romantic ambiance, iconic landmarks, and world-class art.",
      "suggestedActivities": ["Visit the Eiffel Tower", "Explore the Louvre Museum", "Stroll along the Seine River"],
      "estimatedCostUSD": "1500-2500",
      "bestTimeToVisit": "Spring (April-May) or Fall (September-October)",
      "imagePrompt": "Romantic view of Eiffel Tower with Seine river at sunset"
    }

    Ensure the entire response is a valid JSON array. If the query is about recent events or requires up-to-date information, use Google Search grounding.
  `;

  const contents: Part[] = [{text: prompt}];
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: [{ parts: contents }],
      config: {
        responseMimeType: "application/json",
        // Only add tools if keywords suggest recent info needed
        // tools: formData.destinationKeywords.toLowerCase().includes("recent") ? [{googleSearch: {}}] : undefined,
      },
    });

    const rawText = response.text;
    const parsedSuggestions = parseJsonFromMarkdown(rawText);
    
    if (!Array.isArray(parsedSuggestions)) {
        console.error("Parsed response from AI is not an array:", parsedSuggestions);
        // Attempt to wrap in array if it's a single object that was mistakenly not wrapped
        if (typeof parsedSuggestions === 'object' && parsedSuggestions !== null) {
          return {suggestions: [
            { ...parsedSuggestions, id: Date.now().toString() } as TripSuggestion
          ]};
        }
        throw new Error("AI response was not in the expected array format.");
    }

    const suggestionsWithIds: TripSuggestion[] = parsedSuggestions.map((s, index) => ({
      ...s,
      id: `${Date.now()}-${index}`,
      isTopSuggestion: index === 0, // Mark the first suggestion as top
    }));

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] | undefined;

    return {suggestions: suggestionsWithIds, groundingChunks};

  } catch (error) {
    console.error("Error fetching travel suggestions from Gemini:", error);
    if (error instanceof Error && error.message.includes("API key not valid")) {
        throw new Error("Invalid API Key. Please check your API_KEY environment variable.");
    }
     // Re-throw the error, or a more user-friendly version of it.
     // If it's a parsing error from parseJsonFromMarkdown, it will already have a message like "AI returned a malformed response..."
    if (error instanceof Error) {
        throw new Error(`Sorry, we couldn't get travel suggestions: ${error.message}. Please try again later.`);
    }
    throw new Error("Sorry, an unknown error occurred while fetching travel suggestions. Please try again later.");
  }
};
